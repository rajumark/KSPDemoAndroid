package com.morfly

/*
@Target(AnnotationTarget.CLASS)
annotation class Function(val name: String)*/

@Retention(AnnotationRetention.SOURCE)
@Target(AnnotationTarget.CLASS)
annotation class Printable


@Retention(AnnotationRetention.SOURCE)
@Target(AnnotationTarget.CLASS)
annotation class ActivityArgs(val param1:String)