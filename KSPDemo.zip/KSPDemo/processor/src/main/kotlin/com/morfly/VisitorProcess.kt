/*
package com.morfly

private  class VisitorProcess : KSVisitorVoid() {
        override fun visitClassDeclaration(classDeclaration: KSClassDeclaration, data: Unit) {
            if (classDeclaration.modifiers.none { it == Modifier.DATA }) {
                logger.error("@Printable must target data class", classDeclaration)
            }

            val dataclassProps = classDeclaration.getAllProperties()
                .filter { it.extensionReceiver == null }
                .toList()

            // .filter { it.type.resolve().isAssignableFrom(typeInt) }
if(dataclassProps.isEmpty()) return

            dataclassProps.forEach {
                logger.warn("=========" + it, null)
            }
            val fileObject=FileSpec.builder(classDeclaration.packageName.asString(),"${
                classDeclaration.simpleName.asString()
            }Ext")

            fileObject.addFunction(FunSpec.builder("Printable")
                .returns(String::class)
                .receiver(classDeclaration.asType(emptyList()).toTypeName())
                .build())

            


        }
    }*/
