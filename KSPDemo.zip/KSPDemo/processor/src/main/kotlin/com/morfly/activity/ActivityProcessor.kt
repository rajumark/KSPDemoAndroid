package com.morfly.activity

import com.google.devtools.ksp.processing.*
import com.google.devtools.ksp.symbol.KSAnnotated
import com.morfly.ActivityArgs
import java.io.OutputStream

class ActivityProcessor(
    val options: Map<String, String>,
    val logger: KSPLogger,
    val codeGenerator: CodeGenerator,
) : SymbolProcessor {
val packageName="raju.shingadiya.kspdemo"
    override fun process(resolver: Resolver): List<KSAnnotated> {

        val symbolsList = resolver.getSymbolsWithAnnotation(ActivityArgs::class.qualifiedName!!)

        //logger.error("checkerror:"+symbolsList.firstOrNull()?.toString(),null)
        //check if source code have any Annotated class or not
        if (symbolsList.iterator().hasNext().not()) return emptyList()

        //make file
        val file = makeFile(resolver)


        file.append("import android.content.Context")
        file.nextLine()
        file.append("import android.content.Intent")
        file.nextLine(2)

        symbolsList.forEach { it.accept(ActivityVisitor(file,logger),Unit) }

        file.close()

        return emptyList()
    }

    private fun makeFile(resolver: Resolver): OutputStream {
        val file = codeGenerator.createNewFile(
            dependencies = Dependencies(false, *resolver.getAllFiles().toList().toTypedArray()),
            packageName = packageName,
            fileName = "ActivitySafeArgsGenerated"
        )
        file.append("package $packageName\n\n\n")

        return file
    }



}

fun OutputStream.nextLine(lineCount: Int = 1) {
    repeat(lineCount) {
        write("\n".toByteArray())
    }
}

fun OutputStream.append(code: String) {
    write(code.toByteArray())
}

fun KSPLogger.print(message:Any?) {
    warn("symbolsList=" + message)

}
fun KSPLogger.error(message:Any?) {
    error("kspError=" + message,null)

}

