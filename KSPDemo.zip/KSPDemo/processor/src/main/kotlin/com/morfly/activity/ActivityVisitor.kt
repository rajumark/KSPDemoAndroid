package com.morfly.activity

import com.google.devtools.ksp.processing.KSPLogger
import com.google.devtools.ksp.symbol.KSClassDeclaration
import com.google.devtools.ksp.symbol.KSVisitorVoid
import java.io.OutputStream

class ActivityVisitor(
    val file: OutputStream,
    val logger: KSPLogger
    ) :KSVisitorVoid() {
    override fun visitClassDeclaration(classDeclaration: KSClassDeclaration, data: Unit) {
        super.visitClassDeclaration(classDeclaration, data)

       /* val listConst=classDeclaration
        logger.error(buildString {
            append(listConst)
        })*/


    }
}