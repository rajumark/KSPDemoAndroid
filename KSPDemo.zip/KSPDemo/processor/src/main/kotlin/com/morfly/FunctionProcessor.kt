@file:Suppress("UnnecessaryVariable")

package com.morfly

import com.google.devtools.ksp.processing.*
import com.google.devtools.ksp.symbol.*
import com.google.devtools.ksp.symbol.Variance.*
import com.google.devtools.ksp.validate
import com.squareup.kotlinpoet.FunSpec
import com.squareup.kotlinpoet.ParameterSpec
import com.squareup.kotlinpoet.ksp.toTypeName

import java.io.OutputStream

class FunctionProcessor(
    val options: Map<String, String>,
    val logger: KSPLogger,
    val codeGenerator: CodeGenerator
) : SymbolProcessor {
    operator fun OutputStream.plusAssign(str: String) {
        this.write(str.toByteArray())
    }

    private lateinit var typeInt: KSType

    private inner class VisitorFunction(val file: OutputStream) : KSVisitorVoid() {

        override fun visitClassDeclaration(classDeclaration: KSClassDeclaration, data: Unit) {
            super.visitClassDeclaration(classDeclaration, data)

            if (classDeclaration.modifiers.none { it == Modifier.DATA }) {
                logger.error("@Printable Anotaion can apply only on DATA class", classDeclaration)
            }

           val properties= classDeclaration.getAllProperties().toList()
               .filter { it.extensionReceiver==null }


          val function=  FunSpec.builder("print").apply {
              val body= buildString {
                  append("println( \"")
                 val bb= properties.map { acc  -> "\$${acc.simpleName.asString()}" }.reduce { acc, s -> acc+" , "+s }
                  append(bb)
                  /*properties.forEach { prop->
                      append("$")
                      append(prop.simpleName.asString())
append(" | ")


                  }*/
                  append("\")")

              }
                properties.forEach { prop->
                    val parameterSpec=ParameterSpec.builder(
                        name=prop.simpleName.asString(),
                        prop.type.resolve().toTypeName()
                    ).build()
                    //addParameter(parameterSpec)
                   // addParameter(prop.simpleName.asString(), listOf(prop.type))
                   // file.write(prop.simpleName.asString().toByteArray())
                }
              receiver(classDeclaration.asType(emptyList()).toTypeName())
              returns(Unit::class)
              addCode(body)
            }.build()
            file+=function.toString()

        }
    }


    override fun process(resolver: Resolver): List<KSAnnotated> {
        typeInt = resolver.builtIns.intType

        val symbols: Sequence<KSAnnotated> = resolver
            // Getting all symbols that are annotated with @Function.
            .getSymbolsWithAnnotation(Printable::class.qualifiedName!!)

        // Making sure we take only class declarations.


        logger.warn("adroidcc:", symbols.firstOrNull())
        // Exit from the processor in case nothing is annotated with @Function.
        if (!symbols.iterator().hasNext()) return emptyList()

        // The generated file will be located at:
        // build/generated/ksp/main/kotlin/com/morfly/GeneratedFunctions.kt
        val file: OutputStream = FileProvide(resolver)
        // Generating package statement.


        val function = FunSpec.builder("Android")

            .build()

        symbols.forEach { it.accept(VisitorFunction(file), Unit) }

       // file += function.toString()
        // Processing each class declaration, annotated with @Function.
        // symbols.forEach { it.accept(Visitor(file), Unit) }

        // Don't forget to close the out stream.
        file.close()

        val unableToProcess = symbols.filterNot { it.validate() }.toList()
        return unableToProcess
    }


    private fun FileProvide(resolver: Resolver): OutputStream {
        val file: OutputStream = codeGenerator.createNewFile(
            // Make sure to associate the generated file with sources to keep/maintain it across incremental builds.
            // Learn more about incremental processing in KSP from the official docs:
            // https://kotlinlang.org/docs/ksp-incremental.html
            dependencies = Dependencies(false, *resolver.getAllFiles().toList().toTypedArray()),
            packageName = "com.morfly",
            fileName = "ExtenstionFunView"
        )
        file += "package com.morfly\n\n\n"
        return file
    }


}
